﻿

using System;


namespace Projet_PSI
{
   
    public class Lien<T> where T : IEquatable<T>
    {
      
        public Noeud<T> noeud1;
        public Noeud<T> noeud2;

 
        public Lien(Noeud<T> noeud1, Noeud<T> noeud2)
        {
            
            this.noeud1 = noeud1 ?? throw new ArgumentNullException(nameof(noeud1));
            this.noeud2 = noeud2 ?? throw new ArgumentNullException(nameof(noeud2));
        }

      
        public Noeud<T> Noeud1
        {
            get { return noeud1; }
            
        }
        public Noeud<T> Noeud2
        {
            get { return noeud2; }
          
        }

        public override string ToString()
        {
            return $"Lien: ({noeud1?.ToString() ?? "null"}) <-> ({noeud2?.ToString() ?? "null"})";
        }
    }
}